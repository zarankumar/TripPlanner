<?php





include'config.php';

$trip=array("cochin","thekkady","allappuzha","trivandrum");
$p = serialize($trip);
 $qq= "insert into trip values('7','$p','admin')";	
mysql_query($qq);
$r=routePlaces('admin');
//print_r($r);

foreach($r as $p)
echo $p;

function routePlaces($tripId)
	{
	$qry="select * from trip where username='$tripId'";
$res=mysql_query($qry);
$row=mysql_fetch_array($res);
$placesArray = unserialize($row[1]);
print_r($placesArray);
		return $placesArray;
	}

?>
